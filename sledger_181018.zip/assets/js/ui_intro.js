/*
2018.10.18 created by coDribble belong to GGOLCREATIVE.
*/

(function(){
'use strict';

makeDepth();
function makeDepth(){
	var $gnb = $('#gnb .gnb-list > li');

	$.each($gnb, function(i, el){
		var el = $( el );

		if( el.children('ul').length ){ // 하위 메뉴 있으면 아이콘 생성
			el.children('a').append('<i class="fa fa-chevron-down" aria-hidden="true"></i>');
		}

		// gnb hover 이벤트
		el.hover(function(){
			var $this = $(this);

			$this.children('a').children('i').addClass('fa-chevron-up');
			$this.children('ul').stop().slideDown('fast');
		}, function(){
			var $this = $(this);

			$this.children('a').children('i').removeClass('fa-chevron-up');
			$this.children('ul').stop().slideUp('fast');
		});

		el.children('a').on('click',function(){
			var $this = $(this);

			if( $this.next('ul').length ){  // 하위 메뉴가 있으면 클릭 방지
				return false;
			}
		});
	});
}

circleMotion(); // dot 모션
function circleMotion(){
	var $dotWrap = $('.circle-wrap .pager-wrap');

	TweenMax.to($dotWrap, 45, {
		delay: 1,
		rotation: 360,
		ease: Linear.easeNone,
		repeat: -1
	});
}

selectLang(); // 푸터 selectbox ui 모션
function selectLang(){
	var $lang = $('#footer .selectbox');

	$lang.children('button').on('click',function(){
		var $this = $(this);

		$this.next('ul').slideToggle('fast');
	});

	$(document).on('click',function(e){
		if ( $lang.has(e.target).length === 0 ) {
			$lang.children('ul').stop().slideUp('fast');
		}
	});
}

})()